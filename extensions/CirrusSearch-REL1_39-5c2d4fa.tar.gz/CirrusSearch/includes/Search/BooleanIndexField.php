<?php

namespace CirrusSearch\Search;

/**
 * Index field representing boolean value.
 * @package CirrusSearch
 */
class BooleanIndexField extends CirrusIndexField {
	protected $typeName = 'boolean';
}
