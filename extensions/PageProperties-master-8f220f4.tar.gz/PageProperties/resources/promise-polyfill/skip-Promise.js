return typeof Promise === 'function' && Promise.prototype.finally;
